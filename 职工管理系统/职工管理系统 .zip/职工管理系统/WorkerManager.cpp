#include "workermanager.h"
#include <limits>
#include <sstream>
#include <cstdio>
#include <vector>
#ifdef _WIN32
#include <Windows.h>
#endif

namespace
{
    // 读取整数时处理字母等非法输入，避免 cin 进入 fail 状态后程序无法继续。
    bool ReadInt(int& value)
    {
        while (true)
        {
            if (cin >> value)
            {
                return true;
            }
            if (cin.eof())
            {
                return false;
            }
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "输入无效，请输入整数：" << endl;
        }
    }

    void PauseAndClear()
    {
        system("pause");
        system("cls");
    }

    Worker* CreateWorker(int id, const string& name, int deptId)
    {
        switch (deptId)
        {
        case 1: return new Employee(id, name, deptId);
        case 2: return new Manager(id, name, deptId);
        case 3: return new Boss(id, name, deptId);
        default: return NULL;
        }
    }
}

WorkerManager::WorkerManager()
{
    this->m_EmpNum = this->get_EmpNum();
    this->m_EmpArray = NULL;
    this->m_FileIsEmpty = (this->m_EmpNum == 0);

    if (this->m_EmpNum > 0)
    {
        this->m_EmpArray = new Worker * [this->m_EmpNum]();
        this->init_Emp();
    }
}

void WorkerManager::Show_Menu()
{
    cout << "********************************************" << endl;
    cout << "*********  欢迎使用职工管理系统!  **********" << endl;
    cout << "*************  0.退出管理程序  *************" << endl;
    cout << "*************  1.增加职工信息  *************" << endl;
    cout << "*************  2.显示职工信息  *************" << endl;
    cout << "*************  3.删除离职职工  *************" << endl;
    cout << "*************  4.修改职工信息  *************" << endl;
    cout << "*************  5.查找职工信息  *************" << endl;
    cout << "*************  6.按照编号排序  *************" << endl;
    cout << "*************  7.清空所有文档  *************" << endl;
    cout << "********************************************" << endl << endl;
}

void WorkerManager::ExitSystem()
{
    cout << "欢迎下次使用" << endl;
}

void WorkerManager::Add_Emp()
{
    cout << "请输入添加职工数量：" << endl;
    int addNum = 0;
    if (!ReadInt(addNum)) return;
    if (addNum <= 0 || addNum > 100000 - this->m_EmpNum)
    {
        cout << "添加数量必须为正数，且不能超过系统允许的最大人数！" << endl;
        PauseAndClear();
        return;
    }

    const int newSize = this->m_EmpNum + addNum;
    Worker** newSpace = new Worker * [newSize]();
    for (int i = 0; i < this->m_EmpNum; ++i)
    {
        newSpace[i] = this->m_EmpArray[i];
    }

    for (int i = 0; i < addNum; ++i)
    {
        int id = 0;
        string name;
        int deptId = 0;

        while (true)
        {
            cout << "请输入第 " << i + 1 << " 个新职工编号：" << endl;
            if (!ReadInt(id))
            {
                for (int j = this->m_EmpNum; j < this->m_EmpNum + i; ++j) delete newSpace[j];
                delete[] newSpace;
                return;
            }
            bool duplicated = false;
            for (int j = 0; j < this->m_EmpNum + i; ++j)
            {
                if (newSpace[j] != NULL && newSpace[j]->m_Id == id)
                {
                    duplicated = true;
                    break;
                }
            }
            if (!duplicated) break;
            cout << "该职工编号已存在，请重新输入！" << endl;
        }

        cout << "请输入第 " << i + 1 << " 个新职工姓名（暂不支持空格）：" << endl;
        if (!(cin >> name))
        {
            for (int j = this->m_EmpNum; j < this->m_EmpNum + i; ++j) delete newSpace[j];
            delete[] newSpace;
            return;
        }

        while (true)
        {
            cout << "请选择该职工的岗位：1、普通职工  2、经理  3、老板" << endl;
            if (!ReadInt(deptId))
            {
                for (int j = this->m_EmpNum; j < this->m_EmpNum + i; ++j) delete newSpace[j];
                delete[] newSpace;
                return;
            }
            if (deptId >= 1 && deptId <= 3) break;
            cout << "岗位编号只能是 1、2 或 3，请重新输入！" << endl;
        }
        newSpace[this->m_EmpNum + i] = CreateWorker(id, name, deptId);
    }

    Worker** oldArray = this->m_EmpArray;
    const int oldNum = this->m_EmpNum;
    const bool oldEmpty = this->m_FileIsEmpty;
    this->m_EmpArray = newSpace;
    this->m_EmpNum = newSize;
    this->m_FileIsEmpty = false;

    if (this->save())
    {
        delete[] oldArray; // 只释放旧指针数组，职工对象由 newSpace 继续管理。
        cout << "成功添加 " << addNum << " 名职工并保存到文件！" << endl;
    }
    else
    {
        this->m_EmpArray = oldArray;
        this->m_EmpNum = oldNum;
        this->m_FileIsEmpty = oldEmpty;
        for (int i = oldNum; i < newSize; ++i) delete newSpace[i];
        delete[] newSpace;
        cout << "保存失败，已撤销本次添加，原数据保持不变！" << endl;
    }
    PauseAndClear();
}

bool WorkerManager::save()
{
    const string tempFile = string(FILENAME) + ".tmp";
    ofstream ofs(tempFile.c_str(), ios::out | ios::trunc);
    if (!ofs.is_open())
    {
        cout << "临时文件打开失败，保存失败！" << endl;
        return false;
    }

    for (int i = 0; i < this->m_EmpNum; ++i)
    {
        if (this->m_EmpArray[i] == NULL) continue;
        ofs << this->m_EmpArray[i]->m_Id << ' '
            << this->m_EmpArray[i]->m_Name << ' '
            << this->m_EmpArray[i]->m_DeptId << '\n';
        if (!ofs.good()) break;
    }
    ofs.flush();
    const bool writeSucceeded = ofs.good();
    ofs.close();
    if (!writeSucceeded || ofs.fail())
    {
        std::remove(tempFile.c_str());
        cout << "临时文件写入失败，原数据文件未被替换！" << endl;
        return false;
    }

#ifdef _WIN32
    if (!MoveFileExA(tempFile.c_str(), FILENAME, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
#else
    if (std::rename(tempFile.c_str(), FILENAME) != 0)
#endif
    {
        std::remove(tempFile.c_str());
        cout << "替换数据文件失败，原数据文件保持不变！" << endl;
        return false;
    }
    return true;
}

int WorkerManager::get_EmpNum()
{
    ifstream ifs(FILENAME, ios::in);
    if (!ifs.is_open()) return 0;

    int num = 0;
    string line;
    while (getline(ifs, line))
    {
        istringstream iss(line);
        int id = 0, deptId = 0;
        string name;
        if (iss >> id >> name >> deptId && deptId >= 1 && deptId <= 3) ++num;
    }
    return num;
}

void WorkerManager::init_Emp()
{
    ifstream ifs(FILENAME, ios::in);
    if (!ifs.is_open())
    {
        cout << "文件打开失败，无法读取职工信息！" << endl;
        return;
    }

    int index = 0;
    string line;
    while (getline(ifs, line))
    {
        istringstream iss(line);
        int id = 0, deptId = 0;
        string name;
        if (!(iss >> id >> name >> deptId) || deptId < 1 || deptId > 3) continue;
        if (index >= this->m_EmpNum) break;
        this->m_EmpArray[index] = CreateWorker(id, name, deptId);
        ++index;
    }

    // 若读取过程中出现异常或文件被外部修改，修正实际人数，避免空指针被后续访问。
    if (index != this->m_EmpNum)
    {
        this->m_EmpNum = index;
        this->m_FileIsEmpty = (index == 0);
    }
}

void WorkerManager::Show_Emp()
{
    if (this->m_FileIsEmpty || this->m_EmpNum == 0)
    {
        cout << "文件不存在或记录为空！" << endl;
    }
    else
    {
        for (int i = 0; i < this->m_EmpNum; ++i)
        {
            if (this->m_EmpArray[i] != NULL) this->m_EmpArray[i]->showInfo();
        }
    }
    PauseAndClear();
}

void WorkerManager::Del_Emp()
{
    if (this->m_FileIsEmpty)
    {
        cout << "文件不存在或记录为空！" << endl;
    }
    else
    {
        cout << "请输入想要删除的职工编号：" << endl;
        int id = 0;
        if (!ReadInt(id)) return;
        const int index = this->IsExist(id);
        if (index == -1)
        {
            cout << "删除失败，未找到该职工！" << endl;
        }
        else
        {
            Worker* removed = this->m_EmpArray[index];
            const int oldNum = this->m_EmpNum;
            const bool oldEmpty = this->m_FileIsEmpty;
            for (int i = index; i < oldNum - 1; ++i)
                this->m_EmpArray[i] = this->m_EmpArray[i + 1];
            --this->m_EmpNum;
            this->m_EmpArray[this->m_EmpNum] = NULL;
            this->m_FileIsEmpty = (this->m_EmpNum == 0);
            if (this->save())
            {
                delete removed;
                cout << "删除成功并已保存！" << endl;
            }
            else
            {
                for (int i = oldNum - 1; i > index; --i)
                    this->m_EmpArray[i] = this->m_EmpArray[i - 1];
                this->m_EmpArray[index] = removed;
                this->m_EmpNum = oldNum;
                this->m_FileIsEmpty = oldEmpty;
                cout << "保存失败，已撤销删除，原数据保持不变！" << endl;
            }
        }
    }
    PauseAndClear();
}

int WorkerManager::IsExist(int id)
{
    for (int i = 0; i < this->m_EmpNum; ++i)
    {
        if (this->m_EmpArray[i] != NULL && this->m_EmpArray[i]->m_Id == id) return i;
    }
    return -1;
}

void WorkerManager::Mod_Emp()
{
    if (this->m_FileIsEmpty)
    {
        cout << "文件不存在或记录为空！" << endl;
    }
    else
    {
        cout << "请输入要修改的职工编号：" << endl;
        int oldId = 0;
        if (!ReadInt(oldId)) return;
        const int index = this->IsExist(oldId);
        if (index == -1)
        {
            cout << "修改失败，查无此人！" << endl;
        }
        else
        {
            int newId = 0;
            while (true)
            {
                cout << "请输入新的职工编号：" << endl;
                if (!ReadInt(newId)) return;
                const int existIndex = this->IsExist(newId);
                if (existIndex == -1 || existIndex == index) break;
                cout << "修改失败：该编号已被其他职工使用，请重新输入！" << endl;
            }

            string newName;
            cout << "请输入新的姓名（暂不支持空格）：" << endl;
            if (!(cin >> newName)) return;

            int deptId = 0;
            while (true)
            {
                cout << "请输入新的岗位：1、普通职工  2、经理  3、老板" << endl;
                if (!ReadInt(deptId)) return;
                if (deptId >= 1 && deptId <= 3) break;
                cout << "岗位编号只能是 1、2 或 3，请重新输入！" << endl;
            }

            Worker* replacement = CreateWorker(newId, newName, deptId);
            Worker* original = this->m_EmpArray[index];
            this->m_EmpArray[index] = replacement;
            if (this->save())
            {
                delete original;
                cout << "修改成功并已保存！" << endl;
            }
            else
            {
                this->m_EmpArray[index] = original;
                delete replacement;
                cout << "保存失败，已撤销修改，原数据保持不变！" << endl;
            }
        }
    }
    PauseAndClear();
}

void WorkerManager::Find_Emp()
{
    if (this->m_FileIsEmpty)
    {
        cout << "文件不存在或记录为空！" << endl;
    }
    else
    {
        cout << "请选择查找方式：1、按职工编号查找  2、按姓名查找" << endl;
        int select = 0;
        if (!ReadInt(select)) return;
        if (select == 1)
        {
            cout << "请输入职工编号：" << endl;
            int id = 0;
            if (!ReadInt(id)) return;
            const int index = this->IsExist(id);
            if (index == -1) cout << "查找失败，查无此人！" << endl;
            else this->m_EmpArray[index]->showInfo();
        }
        else if (select == 2)
        {
            cout << "请输入职工姓名（暂不支持空格）：" << endl;
            string name;
            if (!(cin >> name)) return;
            bool found = false;
            for (int i = 0; i < this->m_EmpNum; ++i)
            {
                if (this->m_EmpArray[i] != NULL && this->m_EmpArray[i]->m_Name == name)
                {
                    this->m_EmpArray[i]->showInfo();
                    found = true;
                }
            }
            if (!found) cout << "查找失败，查无此人！" << endl;
        }
        else cout << "输入选项有误！" << endl;
    }
    PauseAndClear();
}

void WorkerManager::Sort_Emp()
{
    if (this->m_FileIsEmpty)
    {
        cout << "文件不存在或记录为空！" << endl;
    }
    else
    {
        cout << "请选择排序方式：1、编号升序  2、编号降序" << endl;
        int select = 0;
        while (true)
        {
            if (!ReadInt(select)) return;
            if (select == 1 || select == 2) break;
            cout << "输入有误，请输入 1 或 2！" << endl;
        }
        vector<Worker*> originalOrder(this->m_EmpArray, this->m_EmpArray + this->m_EmpNum);
        for (int i = 0; i < this->m_EmpNum - 1; ++i)
        {
            int target = i;
            for (int j = i + 1; j < this->m_EmpNum; ++j)
            {
                const int leftId = this->m_EmpArray[target]->m_Id;
                const int rightId = this->m_EmpArray[j]->m_Id;
                if ((select == 1 && leftId > rightId) || (select == 2 && leftId < rightId)) target = j;
            }
            if (target != i)
            {
                Worker* temp = this->m_EmpArray[i];
                this->m_EmpArray[i] = this->m_EmpArray[target];
                this->m_EmpArray[target] = temp;
            }
        }
        if (this->save()) cout << "排序成功并已保存，排序结果如下：" << endl;
        else
        {
            for (int i = 0; i < this->m_EmpNum; ++i) this->m_EmpArray[i] = originalOrder[i];
            cout << "保存失败，已恢复原排序，数据保持不变！" << endl;
        }
        for (int i = 0; i < this->m_EmpNum; ++i) this->m_EmpArray[i]->showInfo();
    }
    PauseAndClear();
}

void WorkerManager::Clean_File()
{
    cout << "确定清空所有职工信息吗？1、确定  2、返回" << endl;
    int select = 0;
    if (!ReadInt(select)) return;
    if (select == 1)
    {
        Worker** oldArray = this->m_EmpArray;
        const int oldNum = this->m_EmpNum;
        const bool oldEmpty = this->m_FileIsEmpty;
        this->m_EmpArray = NULL;
        this->m_EmpNum = 0;
        this->m_FileIsEmpty = true;
        if (this->save())
        {
            for (int i = 0; i < oldNum; ++i) delete oldArray[i];
            delete[] oldArray;
            cout << "清空成功！" << endl;
        }
        else
        {
            this->m_EmpArray = oldArray;
            this->m_EmpNum = oldNum;
            this->m_FileIsEmpty = oldEmpty;
            cout << "清空失败，原数据已保留！" << endl;
        }
    }
    else if (select != 2) cout << "输入选项有误，已返回！" << endl;
    PauseAndClear();
}

WorkerManager::~WorkerManager()
{
    if (this->m_EmpArray != NULL)
    {
        for (int i = 0; i < this->m_EmpNum; ++i) delete this->m_EmpArray[i];
        delete[] this->m_EmpArray;
        this->m_EmpArray = NULL;
    }
}
