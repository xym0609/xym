#include "workermanager.h"
#include <limits>

int main()
{
    WorkerManager wm;
    int choice = 0;
    while (true)
    {
        wm.Show_Menu();
        cout << "请输入您的选择：" << endl;
        if (!(cin >> choice))
        {
            if (cin.eof()) break;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "输入无效，请输入 0 至 7 之间的整数！" << endl;
            continue;
        }

        switch (choice)
        {
        case 0:
            wm.ExitSystem();
            return 0;
        case 1: wm.Add_Emp(); break;
        case 2: wm.Show_Emp(); break;
        case 3: wm.Del_Emp(); break;
        case 4: wm.Mod_Emp(); break;
        case 5: wm.Find_Emp(); break;
        case 6: wm.Sort_Emp(); break;
        case 7: wm.Clean_File(); break;
        default:
            cout << "输入选项有误，请输入 0 至 7 之间的数字！" << endl;
            break;
        }
    }
    return 0;
}
