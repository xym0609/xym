#pragma once
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#include "worker.h"
#include "employee.h"
#include "boss.h"
#include "manager.h"

#define FILENAME "empFile.txt"

class WorkerManager
{
public:
    WorkerManager();
    void Show_Menu();
    void ExitSystem();
    void Add_Emp();
    bool save();
    void init_Emp();
    void Show_Emp();
    int get_EmpNum();
    void Del_Emp();
    int IsExist(int id);
    void Mod_Emp();
    void Find_Emp();
    void Sort_Emp();
    void Clean_File();
    ~WorkerManager();

public:
    int m_EmpNum;
    Worker** m_EmpArray;
    bool m_FileIsEmpty;
};
